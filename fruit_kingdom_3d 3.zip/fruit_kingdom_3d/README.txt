
STORY UPDATE: Includes a five-stage story journal for the Fruit Kings legend. The opening prologue appears on first play; use the 📖 Story button to reread the current chapter. Boss victories advance the story, and story progress is saved with the game.
